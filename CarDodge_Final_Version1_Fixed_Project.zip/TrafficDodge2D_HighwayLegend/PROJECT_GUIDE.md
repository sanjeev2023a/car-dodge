# Traffic Dodge 2D: Highway Legend — AI Asset Prompts & APK Signing Guide

## 1. AI Image Generation Prompts

### Game Logo Prompt (512x512, 1:1 Aspect Ratio)
> **Prompt:**
> Ultra-sleek modern mobile game app icon for "Traffic Dodge 2D: Highway Legend", 512x512 resolution, 1:1 square aspect ratio with clean rounded-square visual balance. Top-down 3/4 isometric-tilted view of an aerodynamic cyber-blue and matte carbon-fiber supercar drifting at extreme speed across a dark midnight asphalt highway. Glowing cyan headlight beams cutting forward and twin crimson-amber tail light trails curving behind the rear spoiler, passing dangerously close to a blurred silver traffic sedan. Minimalist vector-inspired digital illustration with crisp metallic rim lighting, high-contrast obsidian and electric cyan palette, zero text, no typography, no watermarks, studio-grade mobile app store icon finish.

### App Store Screenshot 1 — Core High-Speed Lane Dodging (1080x1920, 9:16 Vertical)
> **Prompt:**
> Vertical 9:16 mobile game screenshot (1080x1920) of a 2D top-down endless highway racing game set at night. A four-lane dark slate asphalt interstate framed by glowing electric-blue metallic guardrails. In the lower third, a sleek cyan sports coupe with glowing dual headlight cones tilts slightly as it switches from lane 2 to lane 3, narrowly dodging between an orange heavy semi-truck in lane 2 and a silver luxury sedan in lane 4. Subtle cyan nitro exhaust sparks trail behind the player car. Clean, ultra-modern dark glassmorphic telemetry HUD bar at the top showing crisp minimalist vector trophy and speedometer icons, no clutter, no watermarks, 60 FPS motion blur streaks along the road edges.

### App Store Screenshot 2 — Near-Miss Combo & Speed Rush (1080x1920, 9:16 Vertical)
> **Prompt:**
> Vertical 9:16 mobile game screenshot (1080x1920) of a top-down 2D highway traffic dodging game during an intense high-speed rush. The player's aerodynamic cyan supercar threads a razor-thin gap between two oncoming traffic vehicles—a crimson sports coupe and an emerald SUV—at 300+ KM/H. Golden-yellow friction sparks erupt laterally between the car doors to signify a precision near-miss overtake. High-velocity wind streaks and glowing neon lane dividers emphasize extreme speed on the dark midnight highway, crisp vector UI aesthetic, high contrast, no watermarks.

### App Store Screenshot 3 — Minimalist Glassmorphic Menu & Telemetry UI (1080x1920, 9:16 Vertical)
> **Prompt:**
> Vertical 9:16 mobile UI/UX showcase screenshot (1080x1920) of a dark-mode 2D racing game start overlay. Over a softly darkened top-down four-lane highway background with glowing cyan lane markers, a centered frosted-glass obsidian card displays a glowing vector supercar shield emblem at the top, clean geometric sans-serif title typography reading "TRAFFIC DODGE 2D", a dual-column score and record telemetry summary box, and a vibrant cyan-to-azure gradient call-to-action button at the bottom. Strictly minimalist luxury motorsport UI aesthetic, zero emojis, razor-sharp vector icons, studio UI design presentation.

### App Store Screenshot 4 — Heavy Traffic Night Gauntlet (1080x1920, 9:16 Vertical)
> **Prompt:**
> Vertical 9:16 mobile game screenshot (1080x1920) showing advanced late-game difficulty in a 2D top-down endless highway racer. Dense multi-lane highway traffic featuring a heavy hauler truck, sports coupes, and sedans staggered across four lanes with one tactical S-curve path open. The player's cyan supercar weaves through the opening with dynamic steering tilt, volumetric headlight beams illuminating the asphalt ahead, and glowing red brake lights reflecting off the wet dark road surface. Clean minimalist top HUD bar, dramatic arcade lighting, no watermarks.

---

## 2. 3-Step Signed APK (V1 + V2) Generation Guide in Android Studio

Following these 3 steps ensures Android's Package Installer and Google Play Protect recognize your cryptographic certificate across all Android versions (Android 7.0 through Android 15) and **prevent the "Harmful App / Unknown Developer" block warning** during installation:

### Step 1: Create a Production Keystore with a 2048-bit RSA Key
1. In Android Studio, open the top menu and select **Build > Generate Signed App Bundle / APK...**
2. Select **APK** and click **Next**.
3. Click **Create new...** under Key store path:
   - Choose a secure path for your `.jks` file (e.g., `highway_legend_release.jks`) and set a strong **Key store password**.
   - Set **Alias** (e.g., `highway_legend_key`), a **Key password**, and set **Validity (years)** to **25** (Google Play requires validity past October 2033).
   - Fill in at least the **First and Last Name** and **Organization** fields under Certificate, then click **OK** and **Next**.

### Step 2: Enable Both V1 (Jar Signature) and V2 (Full APK Signature)
1. Select the **release** build variant.
2. If your Android Studio version displays signature scheme checkboxes, check **both `V1 (Jar Signature)` and `V2 (Full APK Signature)`**.
3. To permanently enforce **V1 + V2 signing** in Gradle (since newer Android Studio versions hide the V1/V2 checkboxes in the wizard UI), add `signingConfig` to your module-level `build.gradle.kts` inside the `android { ... }` block:
   ```kotlin
   signingConfigs {
       create("release") {
           storeFile = file("path/to/highway_legend_release.jks")
           storePassword = "YOUR_KEYSTORE_PASSWORD"
           keyAlias = "highway_legend_key"
           keyPassword = "YOUR_KEY_PASSWORD"
           enableV1Signing = true
           enableV2Signing = true
       }
   }
   buildTypes {
       release {
           signingConfig = signingConfigs.getByName("release")
           isMinifyEnabled = true
           isShrinkResources = true
           proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
       }
   }
   ```

### Step 3: Verify Signature Integrity & Keep Permissions Minimal
1. Click **Create** (or run `./gradlew assembleRelease`) to output `app-release.apk` in `app/release/`.
2. Verify that both V1 and V2 signatures are embedded by running:
   ```bash
   apksigner verify --verbose app/release/app-release.apk
   ```
   Confirm the output prints both `Verified using v1 scheme (JAR signing): true` and `Verified using v2 scheme (APK Signature Scheme v2): true`.
3. Because your `AndroidManifest.xml` requests **only** `INTERNET` and `ACCESS_NETWORK_STATE` (zero SMS, Accessibility, Call Log, Storage, or Package Install permissions) and uses consistent V1+V2 cryptographic signing, Play Protect heuristic scanners will not trigger invasive-permission warnings. Always sign future updates with this exact same `.jks` keystore so your developer reputation accumulates cleanly.
